from pathlib import Path
import sys
from functools import lru_cache
from datetime import timedelta
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from features_base import make_features, PORTS

app = FastAPI(title="Predicción del Río Paraguay", version="0.4.0", description="Sistema académico experimental. Datos históricos hasta 2025-12-31.")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_methods=["GET"], allow_headers=["*"])
DATA = ROOT / "data" / "BASE_MAESTRA_RIO_PARAGUAY_2016_2025_AJUSTADA.xlsx"

@lru_cache(maxsize=1)
def prepared():
    if not DATA.exists():
        raise FileNotFoundError("No se encontró el Excel de datos")
    d = pd.read_excel(DATA, sheet_name="BASE_MAESTRA")
    d["fecha"] = pd.to_datetime(d["fecha"])
    if not d["fecha"].is_unique or not d["fecha"].is_monotonic_increasing:
        raise ValueError("La base no tiene fechas únicas y ordenadas")
    return d, make_features(d)

@lru_cache(maxsize=100)
def model_for(port, horizon):
    file = ROOT / "models" / f"{port.lower()}_{horizon:02d}.joblib"
    if not file.exists():
        raise FileNotFoundError(f"Modelo no disponible: {port}, día {horizon}")
    return joblib.load(file)

def get_data():
    try:
        return prepared()
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(503, str(exc)) from exc

def parse_origin(value, d):
    if value is None:
        return len(d)-1
    try:
        date = pd.Timestamp(value)
        if date.strftime("%Y-%m-%d") != value:
            raise ValueError("formato")
    except (ValueError, TypeError):
        raise HTTPException(422, "Fecha inválida; usar YYYY-MM-DD")
    matches = d.index[d.fecha == date]
    if not len(matches):
        raise HTTPException(422, "Fecha fuera del período disponible")
    return int(matches[0])

@app.get("/health")
def health():
    return {"status": "ok", "dataset_disponible": DATA.exists(), "modelos_disponibles": len(list((ROOT/'models').glob('*.joblib')))}

@app.get("/puertos")
def ports():
    return [{"id": p, "nombre": {"Concepcion": "Concepción", "Asuncion": "Asunción", "Villeta": "Villeta"}[p]} for p in PORTS]

@app.get("/info")
def info():
    d, _ = get_data()
    return {"fecha_minima": d.fecha.min().strftime("%Y-%m-%d"), "fecha_maxima": d.fecha.max().strftime("%Y-%m-%d"), "total_dias": len(d), "horizonte_maximo": 30, "fuentes": ["NASA POWER", "DMH Paraguay", "ANA Brasil"], "estado": "prototipo_academico", "advertencia": "Los datos no están actualizados a la fecha actual. No utilizar para navegación ni decisiones de seguridad."}

@app.get("/historico/{puerto}")
def history(puerto: str, fecha_origen: str | None = None, dias: int = Query(120, ge=1, le=3653)):
    if puerto not in PORTS:
        raise HTTPException(404, "Puerto no encontrado")
    d, _ = get_data()
    ix = parse_origin(fecha_origen, d)
    sub = d.iloc[max(0, ix-dias+1):ix+1]
    return {"puerto": puerto, "niveles": [{"fecha": row.fecha.strftime("%Y-%m-%d"), "nivel_m": round(float(getattr(row, PORTS[puerto])), 3)} for row in sub.itertuples(index=False)]}

@app.get("/metricas/{puerto}")
def metrics(puerto: str):
    if puerto not in PORTS:
        raise HTTPException(404, "Puerto no encontrado")
    path = ROOT/'results'/'metricas_diarias.csv'
    if not path.exists():
        raise HTTPException(503, "Métricas no disponibles")
    d = pd.read_csv(path)
    d = d[(d.puerto == puerto) & (d.modelo == 'Seleccion_validacion') & (d.horizonte.isin([15,30]))]
    return {"puerto": puerto, "evaluacion": "2024-2025", "metricas": d.where(pd.notna(d), None).to_dict('records')}

@app.get("/pronostico/{puerto}")
def forecast(puerto: str, fecha_origen: str | None = None, dias: int = Query(30, ge=1, le=30)):
    if puerto not in PORTS:
        raise HTTPException(404, "Puerto no encontrado")
    d, f = get_data()
    ix = parse_origin(fecha_origen, d)
    if f.loc[ix].isna().any():
        raise HTTPException(422, "Historial insuficiente: seleccionar una fecha posterior")
    origin = d.loc[ix, 'fecha']
    level = float(d.loc[ix, PORTS[puerto]])
    output = []
    for h in range(1, dias+1):
        try:
            artifact = model_for(puerto, h)
        except FileNotFoundError as exc:
            raise HTTPException(503, str(exc))
        features = f.loc[[ix], artifact['features']]
        change = float(artifact['model'].predict(features)[0]) if artifact['model'] is not None else 0.0
        pred = level + change
        q = float(artifact['q90'])
        output.append({"fecha": (origin + timedelta(days=h)).strftime('%Y-%m-%d'), "dia": h, "nivel_estimado_m": round(pred,3), "limite_inferior90_m": round(pred-q,3), "limite_superior90_m": round(pred+q,3), "metodo": artifact['selected']})
    return {"puerto": puerto, "fecha_origen": origin.strftime('%Y-%m-%d'), "nivel_origen_m": level, "fecha_maxima_datos": d.fecha.max().strftime('%Y-%m-%d'), "tipo": "simulacion_historica", "advertencia": "Prototipo académico con observaciones hasta 2025-12-31. Intervalos empíricos aproximados; no garantizan cobertura del 90%.", "pronosticos": output}
