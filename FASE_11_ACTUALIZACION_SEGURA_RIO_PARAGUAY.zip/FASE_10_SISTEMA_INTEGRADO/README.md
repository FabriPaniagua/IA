# Fase 4 — React + API de pronóstico del río Paraguay

Se conserva el entrenamiento de Fase 3: 90 artefactos Ridge sobre variaciones o persistencia, seleccionados por validación 2023. **No se han reentrenado ni mejorado las métricas en esta fase.**

## Ejecutar en Windows 11 (VS Code)
Requisitos: Python 3.11/3.12, Node.js 20+ y npm.

Terminal 1, desde la raíz:
```powershell
py -m pip install -r requirements.txt
py -m uvicorn backend.main:app --reload
```
Terminal 2:
```powershell
cd web
npm install
npm run dev
```
Abrir http://localhost:5173 y Swagger en http://localhost:8000/docs.

## Docker
```powershell
docker compose up --build
```
Interfaz http://localhost:8080 ; API http://localhost:8000/docs.

## Endpoints
- GET /health
- GET /info
- GET /puertos
- GET /historico/{puerto}?fecha_origen=2025-11-01&dias=120
- GET /metricas/{puerto}
- GET /pronostico/{puerto}?fecha_origen=2025-11-01&dias=30

Puertos: Asuncion, Concepcion, Villeta. No usar tildes en rutas.

## Limitaciones y trazabilidad
- Base diaria 2016–2025, NASA/DMH/ANA, 66 imputaciones forward fill y una corrección hipotética 2,58→4,58 m. El Excel conserva el historial de ajustes.
- Modelo de producción del prototipo **no es XGBoost**: es Ridge sobre delta o persistencia, elegido por validación. Los experimentos XGBoost están en Fase 2.
- Métricas 2024–2025 y bandas empíricas calculadas sobre 2023. Cobertura del 90% no garantizada.
- No se utilizan variables meteorológicas futuras. El sistema solo permite simulaciones con fechas históricas.
- No se incluyen mediciones actualizadas a 2026 ni validación hidrológica externa. No usar para navegación.
- No necesita XAMPP ni MySQL. Docker usa API + Nginx/React.

## Pruebas
```powershell
py -m pip install pytest
py -m pytest tests -q
```

**Verificación:** 5 pruebas de API aprobadas. No se pudo verificar la compilación React en este entorno porque npm install agotó el tiempo de espera; ejecutar npm install y npm run build en Windows o Docker.


## Fase 5 — Validación adicional
- Leer `docs/INFORME_VALIDACION.md` y `docs/auditoria_metricas.json`.
- Se agregaron tres pruebas de API y se fijaron las dependencias faltantes de XGBoost y pytest.
- No se modificaron modelos ni resultados.
- Ejecutar: `py -m pytest tests -q`.


## Fase 6: Diagnóstico pareado y regímenes
Ver `docs/INFORME_FASE_6.md` y tres CSV nuevos en `results/`. No se alteraron los modelos ni la API.


## Fase 7 — Bandas conservadoras
Se amplían las bandas con cuantiles de error de validación 2023 (95%, como sensibilidad conservadora). No cambian predicciones puntuales. Ver `docs/FASE_7_CALIBRACION.md` y `results/calibracion_validacion_2023.csv`.


## Fase 8 — Auditoría temporal
Ver `docs/FASE_8_BACKTEST_TEMPORAL.md` y los CSV `results/backtest_*_origen_movil.csv`. Esta fase no modifica modelos ni API.

## Fase 9 — Reentrenamiento anual con ventana expansiva

Ejecutar desde la raíz:

```powershell
py src/retrain_annual.py --input data/BASE_MAESTRA_RIO_PARAGUAY_2016_2025_AJUSTADA.xlsx --output .
```

Se reentrena Ridge al inicio de cada año de prueba (2022, 2023, 2024, 2025) usando únicamente filas cuya **fecha objetivo** sea anterior al 1 de enero del año evaluado. Se generan 24 comparaciones (3 puertos × 2 horizontes × 4 años), contrastando Ridge sobre diferencias de nivel con persistencia. Se evalúan fechas de origen y objetivo dentro del mismo año de prueba, sin usar meteorología futura.

Archivos: `results/reentrenamiento_anual_metricas.csv`, `results/reentrenamiento_anual_comparacion.csv`, `results/reentrenamiento_anual_predicciones.csv`.

**Hallazgo:** Ridge gana 20 de 24 comparaciones; persistencia gana en Concepción durante 2022 y 2024 (ambos horizontes). En 2025 Ridge gana los seis escenarios.

**Alcance:** experimento adicional, no reemplaza los 90 modelos de la API ni recalibra intervalos. La base incluye 66 niveles DMH imputados y una corrección hipotética, lo que debe considerarse al interpretar resultados. Los errores por fecha consecutiva no son independientes debido a horizontes solapados. No es una evaluación en vivo.

## Fase 10: estrategia híbrida, auditoría y actualización

Esta entrega añade **experimentos reproducibles**, sin reemplazar todavía el modelo operativo de FastAPI. Se conserva la API y la UI de la Fase 9. El sistema sigue limitado a simulaciones históricas hasta 2025-12-31.

### 1. Estrategia híbrida Ridge / persistencia

```powershell
py src/evaluate_hybrid.py --root .
```

El script usa `results/reentrenamiento_anual_predicciones.csv`, procedente del experimento de reentrenamiento anual. Para cada año desde 2023 selecciona el método de menor MAE acumulado en años anteriores, sin consultar el año evaluado. En 2022 usa Ridge como arranque predeterminado. Genera `results/hibrido_metricas_anuales.csv` y `results/hibrido_predicciones_anuales.csv`. **No se aplica automáticamente a los 90 modelos de la API**, porque el híbrido todavía no supera a Ridge de forma global.

### 2. Intervalos de predicción

```powershell
py src/interval_tradeoff.py --root .
```

Audita cobertura y ancho medio de los intervalos recalibrados de 2024-2025. Los resultados se guardan en `results/auditoria_intervalos.csv`. No se recalibran sobre las pruebas, ya que hacerlo introduciría fuga de información. Para reducir su ancho de forma válida habría que ajustar una nueva estrategia sobre validación temporal y evaluar en un período posterior independiente.

### 3. Preparación para actualizar datos

```powershell
py src/validate_updates.py --csv nuevas_observaciones.csv --root .
```

El CSV debe tener **exactamente las mismas columnas que `BASE_MAESTRA`**, incluir las observaciones completas y consecutivas desde 2026-01-01 y conservar unidades originales (metros para DMH, centímetros para ANA). El script rechaza fechas repetidas, faltantes, huecos y columnas incorrectas. Si pasa, guarda `data/actualizacion_validada.csv`, **sin modificar la base original ni reentrenar**. No descarga datos de internet ni inventa niveles; para pronósticos actuales siguen siendo necesarias las observaciones nuevas verificadas.

### 4. Pruebas y despliegue

```powershell
py -m pytest -q tests/
cd web
npm install
npm run build
```

El proyecto incluye `Dockerfile.api`, `web/Dockerfile` y `docker-compose.yml`. En un equipo con Docker Engine disponible, ejecutar `docker compose up --build` y abrir `http://localhost:8080`. **La compilación React y el arranque real de Docker aún deben verificarse en un equipo con acceso a npm y Docker.**

### 5. Conclusión del experimento híbrido

En las predicciones anuales de 2022-2025, MAE global ponderado: Ridge **0,4488 m**, persistencia **0,5571 m**, híbrido **0,4653 m**. Por tanto Ridge sigue siendo la elección más defendible entre estas tres variantes. Las métricas pertenecen a este experimento anual, no deben confundirse con los resultados de los 90 modelos diarios desplegados.


## Fase 11: actualización segura

Consultar `http://localhost:8000/estado-datos` para verificar antigüedad y modo de operación. Ver `docs/FASE_11_ACTUALIZACION_SEGURA.md`. No se han añadido datos de 2026 ni modificado los modelos.
